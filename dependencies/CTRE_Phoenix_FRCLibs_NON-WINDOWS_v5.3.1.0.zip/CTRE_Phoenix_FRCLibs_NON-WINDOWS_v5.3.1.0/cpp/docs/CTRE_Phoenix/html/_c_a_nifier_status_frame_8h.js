var _c_a_nifier_status_frame_8h =
[
    [ "CANifierStatusFrame", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1", [
      [ "CANifierStatusFrame_Status_1_General", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1aabe25a7075bf8caeddf624efe011b108", null ],
      [ "CANifierStatusFrame_Status_2_General", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1a22ee495598b3da356aa2fa70cc235017", null ],
      [ "CANifierStatusFrame_Status_3_PwmInputs0", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1ae335e57d964ce1e906f57e6163d85ec9", null ],
      [ "CANifierStatusFrame_Status_4_PwmInputs1", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1ab88335b90b2fe204b34ec3bc57e13a3d", null ],
      [ "CANifierStatusFrame_Status_5_PwmInputs2", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1a573b779a7f0da2df5ba537b2074351dd", null ],
      [ "CANifierStatusFrame_Status_6_PwmInputs3", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1a7300469dcafbc7538b6ed138678e084e", null ],
      [ "CANifierStatusFrame_Status_8_Misc", "_c_a_nifier_status_frame_8h.html#a3bc94ec796977474d116f35216c77bb1a051bad8a17a13f464ba7dbee58e778ca", null ]
    ] ]
];