var _remote_sensor_source_8h =
[
    [ "RemoteSensorSource", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bd", [
      [ "RemoteSensorSource_Off", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda1f659e8cbc6a195560056ca422c8c627", null ],
      [ "RemoteSensorSource_TalonSRX_SelectedSensor", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdac651a7a3994f440a3c763a6f2a662b62", null ],
      [ "RemoteSensorSource_Pigeon_Yaw", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda6371784df8bdb430a0a4ae69106405a2", null ],
      [ "RemoteSensorSource_Pigeon_Pitch", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdad76903a292e6f99f55660263db0e5611", null ],
      [ "RemoteSensorSource_Pigeon_Roll", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda912ab648708bc2285f1d767a496a66d1", null ],
      [ "RemoteSensorSource_CANifier_Quadrature", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdab790f858716f201952657e36add59eaa", null ],
      [ "RemoteSensorSource_CANifier_PWMInput0", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda27afee5ca7f6d4fe26f3f001c27b5c6a", null ],
      [ "RemoteSensorSource_CANifier_PWMInput1", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda8fc52d85a70dfe06598f5c5efe81c8b4", null ],
      [ "RemoteSensorSource_CANifier_PWMInput2", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda521cf505400a843617dc5e4a93ca46c6", null ],
      [ "RemoteSensorSource_CANifier_PWMInput3", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdaf089438351098d3d3cefcae089c62bb8", null ],
      [ "RemoteSensorSource_GadgeteerPigeon_Yaw", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bda345e2c2663f4a727229ec0cef7abf9b4", null ],
      [ "RemoteSensorSource_GadgeteerPigeon_Pitch", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdac04f41078ff13b398452e7d2ec4ebae5", null ],
      [ "RemoteSensorSource_GadgeteerPigeon_Roll", "_remote_sensor_source_8h.html#a5a30b4898399484281d7f793f01be9bdaad05711c13b27e9b8a8a991c389a8fb8", null ]
    ] ]
];