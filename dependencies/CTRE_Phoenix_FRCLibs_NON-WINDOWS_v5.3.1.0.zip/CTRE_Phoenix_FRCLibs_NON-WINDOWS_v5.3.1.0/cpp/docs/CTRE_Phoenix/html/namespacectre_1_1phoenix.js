var namespacectre_1_1phoenix =
[
    [ "motion", "namespacectre_1_1phoenix_1_1motion.html", "namespacectre_1_1phoenix_1_1motion" ],
    [ "motorcontrol", "namespacectre_1_1phoenix_1_1motorcontrol.html", "namespacectre_1_1phoenix_1_1motorcontrol" ],
    [ "platform", "namespacectre_1_1phoenix_1_1platform.html", "namespacectre_1_1phoenix_1_1platform" ],
    [ "sensors", "namespacectre_1_1phoenix_1_1sensors.html", "namespacectre_1_1phoenix_1_1sensors" ],
    [ "signals", "namespacectre_1_1phoenix_1_1signals.html", "namespacectre_1_1phoenix_1_1signals" ],
    [ "tasking", "namespacectre_1_1phoenix_1_1tasking.html", "namespacectre_1_1phoenix_1_1tasking" ],
    [ "CANifier", "classctre_1_1phoenix_1_1_c_a_nifier.html", "classctre_1_1phoenix_1_1_c_a_nifier" ],
    [ "CANifierFaults", "structctre_1_1phoenix_1_1_c_a_nifier_faults.html", "structctre_1_1phoenix_1_1_c_a_nifier_faults" ],
    [ "CANifierStickyFaults", "structctre_1_1phoenix_1_1_c_a_nifier_sticky_faults.html", "structctre_1_1phoenix_1_1_c_a_nifier_sticky_faults" ],
    [ "CTRLogger", "classctre_1_1phoenix_1_1_c_t_r_logger.html", null ],
    [ "HsvToRgb", "classctre_1_1phoenix_1_1_hsv_to_rgb.html", null ],
    [ "LinearInterpolation", "classctre_1_1phoenix_1_1_linear_interpolation.html", null ],
    [ "RCRadio3Ch", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html", "classctre_1_1phoenix_1_1_r_c_radio3_ch" ],
    [ "Stopwatch", "classctre_1_1phoenix_1_1_stopwatch.html", "classctre_1_1phoenix_1_1_stopwatch" ],
    [ "Utilities", "classctre_1_1phoenix_1_1_utilities.html", null ]
];