var _control_mode_8h =
[
    [ "ControlMode", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520c", [
      [ "PercentOutput", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca948e4780cea494fc8017f87593b65687", null ],
      [ "Position", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca52f5e0bc3859bc5f5e25130b6c7e8881", null ],
      [ "Velocity", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca88156d46910a2d733443c339a9231d12", null ],
      [ "Current", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca222a267cc5778206b253be35ee3ddab5", null ],
      [ "Follower", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca829e620db67faa54c8ca8441f1239d41", null ],
      [ "MotionProfile", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca88fbd988aeddc8939562a9364272b204", null ],
      [ "MotionMagic", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca68e2b0401fc71ab26bad42e12d9d06b6", null ],
      [ "MotionProfileArc", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520ca2bf9593679102dd507467597c23034ce", null ],
      [ "Disabled", "_control_mode_8h.html#a005f39c5a73e9bd580bd62bcb116520cab9f5c797ebbf55adccdd8539a65a0241", null ]
    ] ]
];