var _c_a_nifier_control_frame_8h =
[
    [ "CANifierControlFrame", "_c_a_nifier_control_frame_8h.html#ae6e150ca31c8bd38069cb2e2cd0d338c", [
      [ "CANifier_Control_1_General", "_c_a_nifier_control_frame_8h.html#ae6e150ca31c8bd38069cb2e2cd0d338cab3b4147d6d688b24c5556514eed512df", null ],
      [ "CANifier_Control_2_PwmOutput", "_c_a_nifier_control_frame_8h.html#ae6e150ca31c8bd38069cb2e2cd0d338cab9379755113e596377b17af09a89edd7", null ]
    ] ]
];