var _demand_type_8h =
[
    [ "DemandType", "_demand_type_8h.html#a1e1df45f3a34a455bde60488159acb12", [
      [ "DemandType_Neutral", "_demand_type_8h.html#a1e1df45f3a34a455bde60488159acb12a05bf5f64731c0a1b1c0a103c81b3e3ea", null ],
      [ "DemandType_AuxPID", "_demand_type_8h.html#a1e1df45f3a34a455bde60488159acb12ad4cd1e1051182fbf62bb7437d3a83dfd", null ],
      [ "DemandType_ArbitraryFeedForward", "_demand_type_8h.html#a1e1df45f3a34a455bde60488159acb12a36fbe3d74d3229607e066e5014c16059", null ]
    ] ]
];