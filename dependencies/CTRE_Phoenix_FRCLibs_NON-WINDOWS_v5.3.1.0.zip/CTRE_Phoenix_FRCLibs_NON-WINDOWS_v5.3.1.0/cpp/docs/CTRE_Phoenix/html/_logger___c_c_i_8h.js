var _logger___c_c_i_8h =
[
    [ "c_Logger_Close", "_logger___c_c_i_8h.html#a07dbe17bb273c3efbbaf545b295cee1a", null ],
    [ "c_Logger_Description", "_logger___c_c_i_8h.html#a92d7c67829965a149fa943a7525ce07a", null ],
    [ "c_Logger_Log", "_logger___c_c_i_8h.html#adaf4099e3e23180ab0eda4dc9e5f7978", null ],
    [ "c_Logger_Open", "_logger___c_c_i_8h.html#a6b436ddd1759425e3045b3c09bd173e9", null ]
];