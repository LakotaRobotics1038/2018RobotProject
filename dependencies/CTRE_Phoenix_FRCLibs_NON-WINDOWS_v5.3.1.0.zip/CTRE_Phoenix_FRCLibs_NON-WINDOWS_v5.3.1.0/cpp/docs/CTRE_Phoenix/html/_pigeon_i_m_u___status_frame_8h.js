var _pigeon_i_m_u___status_frame_8h =
[
    [ "PigeonIMU_StatusFrame", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47d", [
      [ "PigeonIMU_CondStatus_1_General", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47daf9f08e8154150611419c58c529f50179", null ],
      [ "PigeonIMU_CondStatus_9_SixDeg_YPR", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da81d1eec713b5444519ff46ad7a10b9d9", null ],
      [ "PigeonIMU_CondStatus_6_SensorFusion", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da27a8a1ee8f936237e9a51f7f0424d692", null ],
      [ "PigeonIMU_CondStatus_11_GyroAccum", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da0ae2cdfb88640d952d1719ecc5f2bbba", null ],
      [ "PigeonIMU_CondStatus_2_GeneralCompass", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da0355421ee10f24f56281cae0996c5249", null ],
      [ "PigeonIMU_CondStatus_3_GeneralAccel", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47daee0f222ba48a9e41d974da36d95f1087", null ],
      [ "PigeonIMU_CondStatus_10_SixDeg_Quat", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da6f3d0c729326fc452ba2e1f24ebd0ca8", null ],
      [ "PigeonIMU_RawStatus_4_Mag", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da0f55d4add84f5411a6630b00819eebd7", null ],
      [ "PigeonIMU_BiasedStatus_2_Gyro", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da28a1058f697461a552b1681de8be499d", null ],
      [ "PigeonIMU_BiasedStatus_4_Mag", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da4187f3a9a2f8c7d4ab34aa73116cb925", null ],
      [ "PigeonIMU_BiasedStatus_6_Accel", "_pigeon_i_m_u___status_frame_8h.html#a8fc37ddfdba739334f03a70b9f6cf47da916dc732bbdb72912db8db2abe026399", null ]
    ] ]
];