var classctre_1_1phoenix_1_1_r_c_radio3_ch =
[
    [ "Channel", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af5c11d754c4dbff818ae21add7a00768", [
      [ "Channel1", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af5c11d754c4dbff818ae21add7a00768a68b1c2505acf48dcdbb107799c69fabd", null ],
      [ "Channel2", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af5c11d754c4dbff818ae21add7a00768abee9179f38578c1ce46e4dfc9df1a16c", null ],
      [ "Channel3", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af5c11d754c4dbff818ae21add7a00768ab89cb824a12142f577c7631d4f1b73ea", null ]
    ] ],
    [ "Status", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af99fce9bcc1e054733746ab7bf3c1389", [
      [ "LossOfCAN", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af99fce9bcc1e054733746ab7bf3c1389a8286dc3ffc7bc418fe95c69d7a073c70", null ],
      [ "LossOfPwm", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af99fce9bcc1e054733746ab7bf3c1389aa854295a78da860ef1f0e4a3bdb7949f", null ],
      [ "Okay", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af99fce9bcc1e054733746ab7bf3c1389ae7457be51a7c8f63765be05315f61681", null ]
    ] ],
    [ "RCRadio3Ch", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#a4038767be1ac1000e975fe9fd21a866b", null ],
    [ "GetDutyCyclePerc", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#a891ad7cc94d704f4fc852d6e805df21c", null ],
    [ "GetDutyCycleUs", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#a116f11a8f530a7844b12358024974046", null ],
    [ "GetPeriodUs", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#ac9037bc95c6f8218d1094185ea96b1ba", null ],
    [ "GetSwitchValue", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#aaca9363e8900b3d26b268b1c7524aab3", null ],
    [ "Process", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#a5991479586ea5069248534c35896b20f", null ],
    [ "CurrentStatus", "classctre_1_1phoenix_1_1_r_c_radio3_ch.html#a8d0c0d5a93341b7ac2f871016ec12de8", null ]
];