var _follower_type_8h =
[
    [ "FollowerType", "_follower_type_8h.html#a14845a17b439c39b2ee1e3a311dc5cbb", [
      [ "FollowerType_PercentOutput", "_follower_type_8h.html#a14845a17b439c39b2ee1e3a311dc5cbbae58105d509d46e5f12bc888faa7f898f", null ],
      [ "FollowerType_AuxOutput1", "_follower_type_8h.html#a14845a17b439c39b2ee1e3a311dc5cbbae375965cc19c710caa288c3567fdf862", null ]
    ] ]
];