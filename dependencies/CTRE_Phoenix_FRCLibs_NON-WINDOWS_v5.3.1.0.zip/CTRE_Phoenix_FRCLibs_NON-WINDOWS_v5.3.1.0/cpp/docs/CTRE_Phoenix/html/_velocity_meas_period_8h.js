var _velocity_meas_period_8h =
[
    [ "VelocityMeasPeriod", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73c", [
      [ "Period_1Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73cac42465fe0ad881d88a51f207102eb755", null ],
      [ "Period_2Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73ca322a331a05abbc3a3bffa1867a40b4d9", null ],
      [ "Period_5Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73cae7d0dbab68f05fe5aaa93e0ba5ff8bfd", null ],
      [ "Period_10Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73ca55b78eb103285575db34482df7176db6", null ],
      [ "Period_20Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73ca716de21164c49c5bf75bb632078339ca", null ],
      [ "Period_25Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73ca97e52576fd5eb16c4c64169c518384fa", null ],
      [ "Period_50Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73caeb9cf4587dffe4c4d6f5785492355dfa", null ],
      [ "Period_100Ms", "_velocity_meas_period_8h.html#ac7b007d595c8fa57b817fa56f88ee73cad487cc1016eb91b19e51790e84f5f5eb", null ]
    ] ]
];