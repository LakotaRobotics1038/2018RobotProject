var _c_a_nifier_velocity_meas_period_8h =
[
    [ "CANifierVelocityMeasPeriod", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366", [
      [ "Period_1Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366aee3f88e910d6c865f063a491d8d716cd", null ],
      [ "Period_2Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a14f44572311f0f89cde79ab9b3fe439c", null ],
      [ "Period_5Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a467f4f0840a8a848d153dd68d16df277", null ],
      [ "Period_10Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366ac03af49b482fb5804fbe929537ab0583", null ],
      [ "Period_20Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a062c262d5f9c6b7218d6a70b2d1d697c", null ],
      [ "Period_25Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a293d20cdefeffe95ddd75773dd25205a", null ],
      [ "Period_50Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a2cf2b7578af2e6c5e78c4be859eacd99", null ],
      [ "Period_100Ms", "_c_a_nifier_velocity_meas_period_8h.html#ad5e520886a38931369bef35679304366a75a6d3431e8a7ffa3cb974d2fdeae0e7", null ]
    ] ]
];