var namespacectre_1_1phoenix_1_1motion =
[
    [ "MotionProfileStatus", "structctre_1_1phoenix_1_1motion_1_1_motion_profile_status.html", "structctre_1_1phoenix_1_1motion_1_1_motion_profile_status" ],
    [ "TrajectoryPoint", "structctre_1_1phoenix_1_1motion_1_1_trajectory_point.html", "structctre_1_1phoenix_1_1motion_1_1_trajectory_point" ]
];