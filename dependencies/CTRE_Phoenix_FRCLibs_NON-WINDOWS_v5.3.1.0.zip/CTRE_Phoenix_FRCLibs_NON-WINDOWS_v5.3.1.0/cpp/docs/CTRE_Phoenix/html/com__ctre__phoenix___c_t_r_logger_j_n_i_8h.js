var com__ctre__phoenix___c_t_r_logger_j_n_i_8h =
[
    [ "Java_com_ctre_phoenix_CTRLoggerJNI_JNI_1Logger_1Close", "com__ctre__phoenix___c_t_r_logger_j_n_i_8h.html#a29c772ffd7e2d376fe20510e956e5397", null ],
    [ "Java_com_ctre_phoenix_CTRLoggerJNI_JNI_1Logger_1GetLong", "com__ctre__phoenix___c_t_r_logger_j_n_i_8h.html#a67fac7a86d63f83af3af53ea3411ff65", null ],
    [ "Java_com_ctre_phoenix_CTRLoggerJNI_JNI_1Logger_1GetShort", "com__ctre__phoenix___c_t_r_logger_j_n_i_8h.html#a8dd6e970ea1d387d19d0ed2b1cd3bdc4", null ],
    [ "Java_com_ctre_phoenix_CTRLoggerJNI_JNI_1Logger_1Log", "com__ctre__phoenix___c_t_r_logger_j_n_i_8h.html#a4b9d835c2baddea6bb83404451dca361", null ],
    [ "Java_com_ctre_phoenix_CTRLoggerJNI_JNI_1Logger_1Open", "com__ctre__phoenix___c_t_r_logger_j_n_i_8h.html#aacd4bb1e3fa0eb95ef951b05003167dd", null ]
];