var class_logger_driver =
[
    [ "Close", "class_logger_driver.html#a1164bdb68a1fdf4992db4ea2acedb1fb", null ],
    [ "GetDescription", "class_logger_driver.html#aed19acbcfd150233c71d8b2b24bc448d", null ],
    [ "Log", "class_logger_driver.html#ac529fe7d9caa4c26e3fd2a1ebcb54bb9", null ],
    [ "Looping", "class_logger_driver.html#a407e4059fd7f4cda9b41c79d41be5c7a", null ],
    [ "Open", "class_logger_driver.html#ab06231aa13e7e52a2b0b775491cdaf13", null ]
];