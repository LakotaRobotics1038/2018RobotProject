var _trajectory_point_8h =
[
    [ "TrajectoryPoint", "structctre_1_1phoenix_1_1motion_1_1_trajectory_point.html", "structctre_1_1phoenix_1_1motion_1_1_trajectory_point" ],
    [ "TrajectoryDuration", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0", [
      [ "TrajectoryDuration_0ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0a622b0c59756dc04fac887c9d987a159c", null ],
      [ "TrajectoryDuration_5ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0aae58d87a63ac8773952d38dada79fc48", null ],
      [ "TrajectoryDuration_10ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0a971cda2c4ca30a3452121c88e64ca0b4", null ],
      [ "TrajectoryDuration_20ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0a7f15d0890ffe7725389b073a142a59b7", null ],
      [ "TrajectoryDuration_30ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0a44ef8ddd83d7a223be021db6ea21fe82", null ],
      [ "TrajectoryDuration_40ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0aba120adbd985282cfc283063e6f01755", null ],
      [ "TrajectoryDuration_50ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0a94182c1ca21230c3322617db55349ad9", null ],
      [ "TrajectoryDuration_100ms", "_trajectory_point_8h.html#a79c598e15e7023fce953d14c4d39a0c0ae927793a56c3a16e41225406e12e25b1", null ]
    ] ]
];