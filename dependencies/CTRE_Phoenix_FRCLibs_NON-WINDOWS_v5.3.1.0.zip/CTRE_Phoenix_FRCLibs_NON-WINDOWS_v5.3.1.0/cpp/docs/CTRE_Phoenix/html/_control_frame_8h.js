var _control_frame_8h =
[
    [ "ControlFrameRoutines", "classctre_1_1phoenix_1_1motorcontrol_1_1_control_frame_routines.html", null ],
    [ "ControlFrame", "_control_frame_8h.html#aa7bdcbaa99c71724425594f0075a9954", [
      [ "Control_3_General", "_control_frame_8h.html#aa7bdcbaa99c71724425594f0075a9954a64ffa7df7cea40bf65b954ca56970cbb", null ],
      [ "Control_4_Advanced", "_control_frame_8h.html#aa7bdcbaa99c71724425594f0075a9954a28ea854f0068211bac7bd0489b0032e3", null ],
      [ "Control_6_MotProfAddTrajPoint", "_control_frame_8h.html#aa7bdcbaa99c71724425594f0075a9954af803de99a22e0705527fc355f9a82d9b", null ]
    ] ],
    [ "ControlFrameEnhanced", "_control_frame_8h.html#a8bc1d1998697787b7addb7049045b061", [
      [ "Control_3_General_", "_control_frame_8h.html#a8bc1d1998697787b7addb7049045b061a93854050ed5c6744f0a71e05e56aa95c", null ],
      [ "Control_4_Advanced_", "_control_frame_8h.html#a8bc1d1998697787b7addb7049045b061ae24c853c82f6c5e7cfb4fddec82a3335", null ],
      [ "Control_5_FeedbackOutputOverride_", "_control_frame_8h.html#a8bc1d1998697787b7addb7049045b061a64102329a66da203a2216d27e357a2dd", null ],
      [ "Control_6_MotProfAddTrajPoint_", "_control_frame_8h.html#a8bc1d1998697787b7addb7049045b061ac55c4c8ba991eee54c0e493f217fa75c", null ]
    ] ]
];