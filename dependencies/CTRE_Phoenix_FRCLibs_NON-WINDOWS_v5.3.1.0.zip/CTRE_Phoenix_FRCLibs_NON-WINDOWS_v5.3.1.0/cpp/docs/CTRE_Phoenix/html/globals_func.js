var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "j", "globals_func_j.html", null ]
];