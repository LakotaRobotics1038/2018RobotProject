var _set_value_motion_profile_8h =
[
    [ "SetValueMotionProfile", "_set_value_motion_profile_8h.html#ae14983694711f8fd190f3ba197eb9095", [
      [ "Disable", "_set_value_motion_profile_8h.html#ae14983694711f8fd190f3ba197eb9095a4e808e266907628f69ea7e0dc27e4516", null ],
      [ "Enable", "_set_value_motion_profile_8h.html#ae14983694711f8fd190f3ba197eb9095a929779de3575d6b608eda0e4974d1d61", null ],
      [ "Hold", "_set_value_motion_profile_8h.html#ae14983694711f8fd190f3ba197eb9095a796bb2492ad9820e60f3c99f9fad15fe", null ]
    ] ]
];