var _feedback_device_8h =
[
    [ "FeedbackDevice", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7", [
      [ "None", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a0f90901a8eaf937ebc07c9ab6285215c", null ],
      [ "QuadEncoder", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a6cb3ca51e1a0d491b0e19dab2a4e95db", null ],
      [ "Analog", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a54270ddd189803595b684af1541a1c29", null ],
      [ "Tachometer", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a97ac1d81382c12f2fafba271e4cf73dc", null ],
      [ "PulseWidthEncodedPosition", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a963c4e2be902be6449835a94a4c66ffa", null ],
      [ "SensorSum", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7aa9a9c25230343f0fa30c306e5bc6d3b1", null ],
      [ "SensorDifference", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a74a360669dbc6ee536fbf2b9fa41137a", null ],
      [ "RemoteSensor0", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a9cbd3738b5c0031eaddc8b89312cf15c", null ],
      [ "RemoteSensor1", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a461bee285819275936b72de45df872db", null ],
      [ "SoftwareEmulatedSensor", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7aa227c98eb600792bd4e43db990a2006d", null ],
      [ "CTRE_MagEncoder_Absolute", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a197a2f1ca72fcb88fb4f85ab4e6c3655", null ],
      [ "CTRE_MagEncoder_Relative", "_feedback_device_8h.html#a76df6b51b79bdd3710ddcd6ef43050e7a43f30decfa40a7e99d07d1214eaa44f9", null ]
    ] ],
    [ "RemoteFeedbackDevice", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351f", [
      [ "RemoteFeedbackDevice_None", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fa8e053fc53d9dc674e6d1fd2b66e2d0a2", null ],
      [ "RemoteFeedbackDevice_SensorSum", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fa48dc2a569f389100374311535aa08ae0", null ],
      [ "RemoteFeedbackDevice_SensorDifference", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fad6e47477a4b4c1a426cbb03692a5931d", null ],
      [ "RemoteFeedbackDevice_RemoteSensor0", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fa3bf5256ebd6912c66afc6eff3b7fc567", null ],
      [ "RemoteFeedbackDevice_RemoteSensor1", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fa33d187a5caed0fc0a1bebf965b3815a3", null ],
      [ "RemoteFeedbackDevice_SoftwareEmulatedSensor", "_feedback_device_8h.html#a6cd2a597679bc3b89d392bf484c7351fa1c07c1b5b942b8c706b4ee2227faa607", null ]
    ] ]
];