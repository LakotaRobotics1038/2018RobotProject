var _limit_switch_type_8h =
[
    [ "LimitSwitchRoutines", "classctre_1_1phoenix_1_1motorcontrol_1_1_limit_switch_routines.html", null ],
    [ "LimitSwitchNormal", "_limit_switch_type_8h.html#a5548236d00f8f74df6ba58b1239ae4d1", [
      [ "LimitSwitchNormal_NormallyOpen", "_limit_switch_type_8h.html#a5548236d00f8f74df6ba58b1239ae4d1ab3e73264da88dd730280e9cff43df3da", null ],
      [ "LimitSwitchNormal_NormallyClosed", "_limit_switch_type_8h.html#a5548236d00f8f74df6ba58b1239ae4d1ae7567e1bc093ca5ead7cf3d6994ce37f", null ],
      [ "LimitSwitchNormal_Disabled", "_limit_switch_type_8h.html#a5548236d00f8f74df6ba58b1239ae4d1a2d56ea4168be9b9b83da033a9caae5dd", null ]
    ] ],
    [ "LimitSwitchSource", "_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9", [
      [ "LimitSwitchSource_FeedbackConnector", "_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9a71f8840c4c2d02b596e4e8466edd123d", null ],
      [ "LimitSwitchSource_RemoteTalonSRX", "_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9a14125a487cc4b3423d6bb83a4c94a143", null ],
      [ "LimitSwitchSource_RemoteCANifier", "_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9a6ff07a49659164901322f3e63804917d", null ],
      [ "LimitSwitchSource_Deactivated", "_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9aa88d985e7d457fa3b5ddf31f1e16d353", null ]
    ] ],
    [ "RemoteLimitSwitchSource", "_limit_switch_type_8h.html#a7698d0dc218a2ca9f190d194e5af05e5", [
      [ "RemoteLimitSwitchSource_RemoteTalonSRX", "_limit_switch_type_8h.html#a7698d0dc218a2ca9f190d194e5af05e5a8b16eb11e8a2b06037714ac040a16a6f", null ],
      [ "RemoteLimitSwitchSource_RemoteCANifier", "_limit_switch_type_8h.html#a7698d0dc218a2ca9f190d194e5af05e5a2fd7ef98d3a1bc64268986029410e59c", null ],
      [ "RemoteLimitSwitchSource_Deactivated", "_limit_switch_type_8h.html#a7698d0dc218a2ca9f190d194e5af05e5a9669d161697f9f67b6c9d5a6984af2dd", null ]
    ] ]
];