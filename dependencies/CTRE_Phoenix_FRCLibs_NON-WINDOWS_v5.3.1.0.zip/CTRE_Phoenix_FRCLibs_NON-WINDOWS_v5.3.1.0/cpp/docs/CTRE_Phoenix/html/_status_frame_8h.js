var _status_frame_8h =
[
    [ "StatusFrameRoutines", "classctre_1_1phoenix_1_1motorcontrol_1_1_status_frame_routines.html", "classctre_1_1phoenix_1_1motorcontrol_1_1_status_frame_routines" ],
    [ "StatusFrame", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087", [
      [ "Status_1_General_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a607ae0935f0f6f3c90a53f35785d94e2", null ],
      [ "Status_2_Feedback0_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087ad56af7f284c36af8c0c0f4c1d3b83ed4", null ],
      [ "Status_4_AinTempVbat_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a39b6879816d8a88bd5a88194a929e16a", null ],
      [ "Status_6_Misc_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a71fd8e364a2a402b005c22889a03291d", null ],
      [ "Status_7_CommStatus_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a7717ec90661154962e2ac37b89d8a857", null ],
      [ "Status_9_MotProfBuffer_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087ab7efabad4c4d1bae1dd71cee542dfb42", null ],
      [ "Status_10_MotionMagic_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a5b24acdb45692eb629ab5d84d9fcffc9", null ],
      [ "Status_10_Targets_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a0eb3125b153aab0bcd159bb966c89f6c", null ],
      [ "Status_12_Feedback1_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a6770a819b9ec9644cebf7e928663992c", null ],
      [ "Status_13_Base_PIDF0_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a8448e03d894bece92124330a2a130342", null ],
      [ "Status_14_Turn_PIDF1_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a0dc5e0cfd8f433d330a9b0c2e3c6f95b", null ],
      [ "Status_15_FirmareApiStatus_", "_status_frame_8h.html#adbcb3ed785a15b4a47b54d1130467087a7f60c779ae05d0c4a34ef51c4d7de567", null ]
    ] ],
    [ "StatusFrameEnhanced", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0", [
      [ "Status_1_General", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0acef37edea42909b3c63d1622c8832093", null ],
      [ "Status_2_Feedback0", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a2037694d988a87a1fba663c370d73c3f", null ],
      [ "Status_4_AinTempVbat", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a81ed5cf18761b987ed094533e02c1f31", null ],
      [ "Status_6_Misc", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ab4f135fac0fd317ece47a29604187259", null ],
      [ "Status_7_CommStatus", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ab18c5996851504e8a1d48d7a5ab8cc8d", null ],
      [ "Status_9_MotProfBuffer", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ab82021e7af32925ae915dcb4234856d8", null ],
      [ "Status_10_MotionMagic", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a29021eae76499ed09048d5dbaa203f70", null ],
      [ "Status_10_Targets", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a2c9b9afa586aeca2faa23b66333a5c2b", null ],
      [ "Status_12_Feedback1", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a9d03a99b17bd8a3ff2ee3f64cc5be5b9", null ],
      [ "Status_13_Base_PIDF0", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ac08699540635886ef3b97885c9a1191b", null ],
      [ "Status_14_Turn_PIDF1", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a42277cb6780a7f330790360059e34106", null ],
      [ "Status_15_FirmareApiStatus", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0a4ed4f669bb7716f0f85447bcb2112dfa", null ],
      [ "Status_3_Quadrature", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ab2a8489dca1eb94f6fdcff3f0ded86c4", null ],
      [ "Status_8_PulseWidth", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0ac053087f1ebb43bcbe7c52b10d1b43cc", null ],
      [ "Status_11_UartGadgeteer", "_status_frame_8h.html#a2eb61fd8d8bfb6f8308a740f7d94abf0aae55b69c9a1c8fde63007175db80c08f", null ]
    ] ]
];